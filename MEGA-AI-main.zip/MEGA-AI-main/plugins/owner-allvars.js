const _0x411383 = _0x24cf
;(function (_0x5a4ade, _0x2c18b8) {
  const _0x29845 = _0x24cf,
    _0x534f80 = _0x5a4ade()
  while (!![]) {
    try {
      const _0x542d5d =
        -parseInt(_0x29845(0xfc)) / 0x1 +
        (parseInt(_0x29845(0xf4)) / 0x2) * (parseInt(_0x29845(0xf5)) / 0x3) +
        (parseInt(_0x29845(0xf8)) / 0x4) * (-parseInt(_0x29845(0xfb)) / 0x5) +
        -parseInt(_0x29845(0xfa)) / 0x6 +
        parseInt(_0x29845(0xfe)) / 0x7 +
        (parseInt(_0x29845(0x102)) / 0x8) * (parseInt(_0x29845(0xff)) / 0x9) +
        parseInt(_0x29845(0xeb)) / 0xa
      if (_0x542d5d === _0x2c18b8) break
      else _0x534f80['push'](_0x534f80['shift']())
    } catch (_0x25f1d3) {
      _0x534f80['push'](_0x534f80['shift']())
    }
  }
})(_0x2cfd, 0xe5469)
function _0x24cf(_0x46903a, _0x19fa02) {
  const _0x2cfd84 = _0x2cfd()
  return (
    (_0x24cf = function (_0x24cf87, _0x3ae15b) {
      _0x24cf87 = _0x24cf87 - 0xea
      let _0x5c2102 = _0x2cfd84[_0x24cf87]
      return _0x5c2102
    }),
    _0x24cf(_0x46903a, _0x19fa02)
  )
}
import _0x4d4aa1 from 'heroku-client'
let handler = async (_0x86a940, { isROwner: _0x2e73f1 }) => {
  const _0x5931a0 = _0x24cf
  if (_0x2e73f1) {
    await _0x86a940[_0x5931a0(0x100)](_0x5931a0(0xed))
    const _0x1e52e2 = new _0x4d4aa1({ token: process['env'][_0x5931a0(0xfd)] }),
      _0x1b4f1a = process[_0x5931a0(0xea)]['HAPP']
    try {
      const _0x38a8d1 = await _0x1e52e2[_0x5931a0(0xec)](
          _0x5931a0(0x104) + _0x1b4f1a + _0x5931a0(0x103)
        ),
        _0x56605e = Object[_0x5931a0(0x106)](_0x38a8d1)
          [_0x5931a0(0xf0)](([_0x44c27d, _0xd8d5ee]) => _0x44c27d + ':\x20' + _0xd8d5ee)
          [_0x5931a0(0xf3)]('\x0a')
      await _0x86a940[_0x5931a0(0x100)]('🔍Config\x20Vars:\x0a' + _0x56605e)
    } catch (_0xb64e30) {
      console['error'](_0x5931a0(0xf7), _0xb64e30['message'])
      throw _0x5931a0(0x105)
    }
  } else throw _0x5931a0(0xf9)
}
;(handler[_0x411383(0xee)] = [_0x411383(0xf1)]),
  (handler[_0x411383(0xf2)] = [_0x411383(0xf6)]),
  (handler['command'] = [_0x411383(0x101)]),
  (handler[_0x411383(0xef)] = !![])
export default handler
function _0x2cfd() {
  const _0x1bdc17 = [
    '1394790DpDzYW',
    'HKEY',
    '6776966FPltKs',
    '18hDCkXB',
    'reply',
    'allvars',
    '1358872UdXxae',
    '/config-vars',
    '/apps/',
    'Failed\x20to\x20retrieve\x20config\x20vars.\x20Check\x20logs\x20for\x20details.',
    'entries',
    'env',
    '13766090woCvvn',
    'get',
    '⚙️\x20Retrieving\x20Config\x20Vars...\x0aWait\x20a\x20moment',
    'help',
    'rowner',
    'map',
    'HEROKU',
    'tags',
    'join',
    '152uogGln',
    '56769mdROAk',
    'owner',
    'Error\x20retrieving\x20config\x20vars:',
    '8048rRfXqx',
    'You\x20are\x20not\x20the\x20owner',
    '1388532ZQNuun',
    '3870uUFaQy',
  ]
  _0x2cfd = function () {
    return _0x1bdc17
  }
  return _0x2cfd()
}
