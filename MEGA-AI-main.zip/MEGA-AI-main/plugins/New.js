let handler = async m =>
  m.reply(
    `𝙷𝙾𝙻𝙰 𝚈𝙾𝚄 𝙽𝙴𝙴𝙳 𝙷𝙴𝙻𝙿 𝙾𝙽 𝚂𝙾𝙼𝙴 𝙾𝙵 𝚃𝙷𝙴 𝙰𝙱𝙾𝚅𝙴 𝚃𝙷𝙴𝙽 𝙵𝙾𝙻𝙻𝙾𝚆 𝚃𝙷𝙸𝚂 𝙸𝙽𝚂𝚃𝚁𝙰𝙲𝚃𝙸𝙾𝙽𝚂

    _______________________
    𝑓𝑜𝑙𝑙𝑜𝑤 𝑡ℎ𝑖𝑠 𝑠𝑡𝑒𝑝𝑠 𝑡𝑜 𝑐𝑜𝑛𝑡𝑎𝑐𝑡 𝑢𝑠 

  1. 𝐉𝐨𝐢𝐧 𝐓𝐡𝐢𝐬 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 𝐋𝐢𝐧𝐤 𝐅𝐢𝐫𝐬𝐭 𝐀𝐟𝐭𝐞𝐫 𝐓𝐡𝐢𝐬 𝐌𝐲 𝐎𝐰𝐧𝐞𝐫 𝐖𝐢𝐥𝐥 𝐀𝐧𝐬𝐰𝐞𝐫 𝐘𝐨𝐮
  > *https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07*

  __________________________

  2. 𝐈𝐟 𝐓𝐡𝐢𝐬 𝐈𝐬 𝐍𝐨𝐭 𝐓𝐡𝐞 𝐑𝐞𝐚𝐥 𝐎𝐰𝐧𝐞𝐫 𝐏𝐥𝐞𝐚𝐬𝐞 𝐂𝐨𝐧𝐭𝐚𝐜𝐭 𝐓𝐡𝐞 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐅𝐨𝐫 𝐇𝐞𝐥𝐩
  > *923444844060* *© GlobalTechInfo*
  __________________________


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['mrcs']

export default handler
