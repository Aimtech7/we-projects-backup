// App.jsx – Main entry that renders the Counter UI
import "./App.css"; // Import global styles
import CounterApp from "@/components/CounterApp"; // Alias for component

function App() {
  return <CounterApp />;
}

export default App;
