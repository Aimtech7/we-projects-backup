import { useState, useEffect } from "react";

export default function CounterApp() {
  const limit = 10;

  // Initialize from localStorage, or default to 0
  const [count, setCount] = useState(() => {
    const saved = localStorage.getItem("click-count");
    return saved ? parseInt(saved, 10) : 0;
  });

  // Update localStorage every time count changes
  useEffect(() => {
    localStorage.setItem("click-count", count);
  }, [count]);

  const increment = () => {
    if (count < limit) setCount(count + 1);
  };

  const decrement = () => {
    if (count > 0) setCount(count - 1);
  };

  const reset = () => {
    setCount(0);
  };

  const getProgressPercentage = () => {
    return (count / limit) * 100;
  };

  return (
    <div className="app-container">
      <div className="counter-card">
        {/* Header */}
        <div className="header">
          <h1 className="title">Click Counter</h1>
          <p className="subtitle">Track your clicks with style</p>
        </div>

        {/* Counter display */}
        <div className="counter-display">
          <div className="count-wrapper">
            <div className="count-number">{count}</div>
            <div className="count-glow"></div>
          </div>

          {/* Progress bar */}
          <div className="progress-container">
            <div
              className="progress-bar"
              style={{ width: `${getProgressPercentage()}%` }}
            >
              <div className="progress-shine"></div>
            </div>
          </div>

          <p className="progress-text">
            {count} / {limit} clicks
          </p>
        </div>

        {/* Limit reached message */}
        {count === limit && (
          <div className="limit-message">
            <div className="celebration-badge">
              🎉 You've reached the limit!
            </div>
          </div>
        )}

        {/* Increase/Decrease Buttons */}
        <div className="button-group">
          <button
            onClick={decrement}
            disabled={count === 0}
            className="btn btn-decrease"
          >
            <span className="btn-icon">-</span>
            Decrease
          </button>

          <button
            onClick={increment}
            disabled={count === limit}
            className="btn btn-increase"
          >
            <span className="btn-icon">+</span>
            Increase
          </button>
        </div>

        {/* Reset Button */}
        <div className="reset-container">
          <button onClick={reset} className="btn-reset">
            Reset Counter
          </button>
        </div>

        {/* Stats */}
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-label">Progress</div>
            <div className="stat-value">
              {Math.round(getProgressPercentage())}%
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Remaining</div>
            <div className="stat-value">{limit - count}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
