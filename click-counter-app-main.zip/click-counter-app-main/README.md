
# Click Counter App

A simple React-based click counter app built with Vite. The app allows users to increase or decrease a counter, and handles edge cases like not going below 0 or exceeding a maximum limit.

## Features
- Increment and decrement counter
- Prevent counter from going below 0
- Limit counter to a maximum value (e.g., 10)
- Display a message when the limit is reached
- Clean and responsive UI

## Tech Stack
- React
- Vite
- CSS (inline and file-based)

## Getting Started
1. Clone the repository
2. Run `npm install`
3. Run `npm run dev`
4. Visit `http://localhost:5173`

## Preview
![App Preview](./src/assets/images/preview.png)

---